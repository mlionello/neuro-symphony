# `web/userdata/`: raw per-participant data

Raw JSON session logs and continuous button-press CSVs for the 51 participants
who completed at least one full session within the data-collection window
(14 January - 28 June 2025), as written by the web app
(`web/php/save_experiment_data.php` etc.) — this is the data
`core/extract.py` (in `preprocessing/`) reads to build the analysis-ready
tables.

Not included: test accounts, registrations without a completed session, and
unfinished or partial sessions
(`experiments_log.csv` is filtered accordingly).

## Folder layout

```
web/userdata/
  experiments_log.csv          # append-only log: userid, timestamp, exp_started/finished_id, condition_slot
  user_<hex16>/
    <hex16>.json                # one file per participant: demographics + every experiment/session they did
    exp<N>_traccia<M>.csv       # one file per (experiment, movement): continuous button-press log
    exp<N>_traccia<M>_1.csv     # a repeat attempt of the same track (session was restarted), if present
```

`<hex16>` is a random pseudonymous participant ID and also the value of the
JSON's own `user_id` field.

## JSON structure (per participant)

Top-level keys:

- `demographics_and_GMSI` — one-time screening: `terms`, `demographics`
  (age/gender/education/occupation/childhood_country/mother_tongue/
  psychiatric_treatment/psychiatric_diagnosis), 
  `bigfive` (BFI-10), `goldsmi1`/`goldsmi2` (Gold-MSI).
- `nb.completed` — how many of the 8 symphonies (`exp1`-`exp8`) this
  participant completed.
- `exp1` .. `exp8` — one block per symphony the participant did.

### Inside each `expN` block

- `session_data` — see "Where the condition assignment lives" below.
- `who5` — WHO-5 well-being index.
- `track_1` .. `track_4` — one per movement of that symphony, in listening
  order: `q1_1..q1_3` (felt positive/negative intensity etc.), `q2_1..q2_4`,
  `q3_1..q3_2` (text-music linkage), `feedback` (open-text, per-movement),
  `reading_duration`/`starting_duration`/`questionnaire_duration`/
  `listening_duration` (ms).
- `post_experiment` — end-of-symphony questions: `q1_1..q1_6`,
  `recon_auth`/`recon_auth_value` and `recon_work`/`recon_work_value`
  ("did you recognize the composer/work" + open-text guess, when yes),
  `comments` (open-text, session-level).

## Condition assignment lives — `session_data.cond_per_session`

`exp<N>.session_data.cond_per_session` is a 4-element array, **indexed by
condition, not by track**: position 0 = TT (Reference+Coherent), position 1
= TF (Reference+Opposite), position 2 = FT (Injected+Coherent), position 3 =
FF (Injected+Opposite) — matching `core/extract.py`'s `COND_MAP`. The
**value** at each position is the movement/track number (1-4) that received
that condition for this session.

Example (`user_021f60e41097a159`, `exp2`, Dvořák 8): `cond_per_session =
[3, 2, 4, 1]` means track 3 got TT, track 2 got TF, track 4 got FT, and
track 1 got FF. Equivalently, per-track: track1=FF, track2=TF, track3=TT,
track4=FT.

In `core/extract.py`,
`track_condition = np.where(np.array(cond_per_session) == track_n)[0][0] + 1`
covnerts it into a `condition` column
(TT/TF/FT/FF) in the pipeline's merged output tables.

`session_data.description_indices` (also 4 elements, **sorted ascending, not
aligned to track or condition order by position**) holds the row indices
into that symphony's `<symphony>_processed.csv` (in `web/data/`, see that
folder's own `README.md` for the row layout) that were actually shown —
cross-reference against `cond_per_session` to know which index belongs to
which track/condition, or just trust the full text already embedded in this
JSON.

`session_data.assigned_condition` (e.g. `6`) is a separate, internal
counter the site uses to balance assignment across the 24 precomputed
permutations in `web/data/shuffled_combination_<N>.csv`.

## The full program-note text is stored per participant, not just referenced

`session_data.descriptions` is a 4-element list, **indexed by track order**
(`descriptions[i]` is the text shown before track `i+1`), each item a
`{"description": "<full note text>"}` object — the complete, verbatim
program note the participant actually read, not merely a pointer into
`web/data/<symphony>_processed.csv`. This matters because the FT/FF
(Injected) rows are randomly sampled per session (see `web/data/README.md`),
so two participants in the same nominal condition can see different exact
text.

## Button-press CSVs

`exp<N>_traccia<M>.csv`: first column is a timestamp in milliseconds, the
remaining 6 columns are binary press states (0/1) for the six emotion
buttons, in the order given by that session's own
`session_data.labels` (Power/Energy, Joy/Happiness, Sadness,
Wonder/Surprise, Tension, Calm/Tranquillity — see `core/metrics.py`'s
`load_pressing_csv`).
