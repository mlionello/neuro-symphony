# Program-note corpus: row layout of `<symphony>_processed.csv`

This documents the internal row structure of the 8 `<symphony>_processed.csv`
files in this folder (`beethoven4_processed.csv`, `beethoven6_processed.csv`,
`brahms3_processed.csv`, `dvorak8_processed.csv`, `mendelssohn4_processed.csv`,
`schubert4_processed.csv`, `schumann2_processed.csv`,
`schumann4_processed.csv`) — the full 576-note corpus (18 notes × 4 movements
× 8 symphonies) promised in `article.tex:554` and `rebuttal.txt` (R1.5).
Verified 2026-08-25 against the actual PHP experiment code and the Python
pipeline's condition mapping (not inferred/guessed).

## Layout: 4 contiguous 18-row blocks, one per movement

Each file has 72 rows (`framework.json`'s `number_descriptions_per_mvt: 18`
× `number_mvt: 4`). Rows `[0, 18)` are movement 1's variants, `[18, 36)`
movement 2's, `[36, 54)` movement 3's, `[54, 72)` movement 4's (0-indexed;
this is what `web/php/build_experiment.php`'s `$offset = [0, N, 2N, 3N]`
picks between).

## Within each 18-row movement block: fixed condition-label pattern

Confirmed directly from `web/php/build_experiment.php` (the code that
actually selects which row is shown to a participant), lines ~70-79:

```php
$offset = [0, $num_samples, 2*$num_samples, 3*$num_samples];
$_SESSION['description_indices'][] = $offset[$cond_per_session[0]-1];       // TT: Exact offset
$_SESSION['description_indices'][] = $offset[$cond_per_session[1]-1] + 1;   // TF: offset + 1
$a = rand(2, $num_samples-1); if ($a % 2 != 0) $a -= 1;
$_SESSION['description_indices'][] = $offset[$cond_per_session[2]-1] + $a;  // FT: random EVEN index
$a = rand(3, $num_samples-1); if ($a % 2 == 0) $a -= 1;
$_SESSION['description_indices'][] = $offset[$cond_per_session[3]-1] + $a;  // FF: random ODD index
```

i.e. within a movement's 18-row block, row 0 is always TT, row 1 is always
TF, and rows 2-17 alternate FT (even index) / FF (odd index), with one of
each sampled at random per session:

```
row:       0    1    2    3    4    5    6    7    8    9   10   11   12   13   14   15   16   17
condition: TT   TF   FT   FF   FT   FF   FT   FF   FT   FF   FT   FF   FT   FF   FT   FF   FT   FF
```

So TT and TF each have exactly **one** canonical version in the corpus per
movement; FT and FF each have **8** candidate variants (one randomly sampled
per participant session).

## Condition-code letters: (Narrative Authenticity, Affective Coherence)

Confirmed from `scripts/build_dataset.py`'s `CONDITION_MAPS` (itself
validated row-for-row against the legacy MATLAB `aggregate_aff_inj.m`):

```python
CONDITION_MAPS = {
    "aggregated_condition_affective": {1: "Aff Coher", 2: "Aff Opp", 3: "Aff Coher", 4: "Aff Opp"},
    "aggregated_condition_injected":  {1: "Ref",       2: "Ref",     3: "Inj",       4: "Inj"},
}
```

with `track_condition` 1-4 mapped to `TT`/`TF`/`FT`/`FF` by
`core/extract.py`'s `COND_MAP`. Cross-referencing the two:

| code | narrative authenticity (1st letter) | affective coherence (2nd letter) |
|------|--------------------------------------|-----------------------------------|
| TT   | T = Reference                        | T = Coherent                      |
| TF   | T = Reference                        | F = Opposite                      |
| FT   | F = Injected                          | T = Coherent                      |
| FF   | F = Injected                          | F = Opposite                      |

So the letter order is **(narrative authenticity, affective coherence)** —
first letter Reference(T)/Injected(F), second letter Coherent(T)/Opposite(F).
(Note: CLAUDE.md's prose gloss "coherence × narrative-authenticity factorial"
names the two factors in the manuscript's discussion order, not this literal
code order — the two aren't the same thing and shouldn't be conflated.)

## Where to find the corresponding valence/arousal ratings

`article.tex`'s LLM pipeline step **(6) Text correction and affective
scoring** (`article.tex:179-183`; full prompt in Appendix, "Step 6b —
Affective scoring (GPT-4o-mini)", `article.tex:573`) scores every text in
this corpus for continuous valence/arousal (0-10). Those per-text scores are
**not** in this folder — they live in `neurosymphony/data/programnotes/ratings/`:

- In this repo's ecosystem: `data/programnotes/ratings/sorted_<symphony>_rating.csv`
  (already present and git-tracked in the public release repo, at
  `/code/neuro-symphony/neurosymphony/data/programnotes/ratings/`).
- Also found at
  `/code/music_context/music_context/sinossi/out_sinossi_injected_gpt4_alt_corrected/new_ratings/sorted_<symphony>_rating.csv`
  (byte-identical to the release-repo copy, confirmed for `schumann4`) — this
  is the path `MATLAB_AGGREGATION_PIPELINE.md` and this repo's own
  `--ratings` CLI flag (`scripts/extract_final.py`, `core/extract.py`'s
  `_load_ratings`) expect, e.g.
  `--ratings /path/to/sinossi/out_sinossi_injected_gpt4_alt_corrected/new_ratings`
  in that external `music_context` repo, or
  `--ratings ../data/programnotes/ratings` for this repo's own copy.
  `music_context_code_cleaned` itself has no local `sinossi/` copy — this
  folder is always supplied externally via that flag.
- `core/extract.py`'s `_load_ratings` derives the filename from
  `description_path`'s stem (e.g. `brahms3_processed` → first
  underscore-segment `brahms3` → `sorted_brahms3_rating.csv`).

**Row alignment**: each `sorted_<symphony>_rating.csv` has the same 72-row,
18-per-movement-block layout as its `<symphony>_processed.csv`, and
`core/extract.py` indexes both by the *same* row number
(`description_line`/`target_line`) — confirmed by inspecting
`sorted_schumann4_rating.csv`'s `filename`/`mvt_id`/`trueOrInference`
columns against the TT/TF/FT/FF pattern above: within each 18-row block,
rows 0-1 are labeled `filename="Reference Work"` (`trueOrInference` `True`
at row 0 = the TT/Coherent slot, `False` at row 1 = the TF/Opposite slot),
and rows 2-17 cycle through the 8 donor symphonies used for injection
(`Beethoven5_0, Mahler6_0, Mendelssohn5_0, Mendelssohn9_0, Schubert1_0,
Schubert2_0, Schubert6_0, Schumann1_0` — the exact list and order from
`inject_affect_to_sinossi.py`'s `valid_comparisons`), each donor contributing
one `True` row (FT/Coherent slot) and one `False` row (FF/Opposite slot).
So `trueOrInference` despite its name actually encodes the affective-valence
slot (Coherent=`True`, Opposite=`False`), not narrative authenticity.

Relevant columns: `valence_mean`/`valence_std`/`valence_trend_slope`/
`valence_curvature` and the `arousal_*` equivalents (per-sentence trend
statistics, retained but not used as predictors), plus `score_mvt_valence`/
`score_mvt_arousal` (the whole-text average score, used as the continuous
predictor — this is what `core/extract.py` copies into
`description_score_mvt_valence` etc.).

## Four-condition representative excerpt

This resolves the previously-open "four-condition excerpt" item
(`article.tex:554`, `rebuttal.txt` R1.5): for any symphony/movement, its four
displayed-condition texts are, within that movement's 18-row block:

- row 0 → TT (Reference, Coherent)
- row 1 → TF (Reference, Opposite)
- one of rows {2,4,6,8,10,12,14,16} → FT (Injected, Coherent)
- one of rows {3,5,7,9,11,13,15,17} → FF (Injected, Opposite)

An actual excerpt file (picking one specific FT/FF row per the recommended
random sampling, or just row 2 and row 3 as canonical picks) still needs to
be created and added here — this README only documents how to construct it,
it isn't the excerpt itself.
