# Program-note corpus: row layout of `<symphony>_processed.csv`

This documents the internal row structure of the 8 `<symphony>_processed.csv`
files in this folder (`beethoven4_processed.csv`, `beethoven6_processed.csv`,
`brahms3_processed.csv`, `dvorak8_processed.csv`, `mendelssohn4_processed.csv`,
`schubert4_processed.csv`, `schumann2_processed.csv`,
`schumann4_processed.csv`) — the full 576-note corpus (18 notes × 4 movements
× 8 symphonies).

## Layout: 4 contiguous 18-row blocks, one per movement

Each file has 72 rows (`framework.json`'s `number_descriptions_per_mvt: 18`
× `number_mvt: 4`). Rows `[0, 18)` are movement 1's variants, `[18, 36)`
movement 2's, `[36, 54)` movement 3's, `[54, 72)` movement 4's (0-indexed;
this is what `web/php/build_experiment.php`'s `$offset = [0, N, 2N, 3N]`
picks between).

## Within each 18-row movement block: fixed condition-label pattern

From `web/php/build_experiment.php`, lines ~70-79:

```php
$offset = [0, $num_samples, 2*$num_samples, 3*$num_samples];
$_SESSION['description_indices'][] = $offset[$cond_per_session[0]-1];       // TT: Exact offset
$_SESSION['description_indices'][] = $offset[$cond_per_session[1]-1] + 1;   // TF: offset + 1
$a = rand(2, $num_samples-1); if ($a % 2 != 0) $a -= 1;
$_SESSION['description_indices'][] = $offset[$cond_per_session[2]-1] + $a;  // FT: random EVEN index
$a = rand(3, $num_samples-1); if ($a % 2 == 0) $a -= 1;
$_SESSION['description_indices'][] = $offset[$cond_per_session[3]-1] + $a;  // FF: random ODD index
```

i.e. within a movement's 18-row block, row 0 is always TT, row 1 is always
TF, and rows 2-17 alternate FT (even index) / FF (odd index), with one of
each sampled at random per session:

```
row:       0    1    2    3    4    5    6    7    8    9   10   11   12   13   14   15   16   17
condition: TT   TF   FT   FF   FT   FF   FT   FF   FT   FF   FT   FF   FT   FF   FT   FF   FT   FF
```

So TT and TF each have exactly **one** canonical version in the corpus per
movement; FT and FF each have **8** candidate variants (one randomly sampled
per participant session).

## Condition-code letters: (Narrative Authenticity, Affective Coherence)

Confirmed from `scripts/build_dataset.py`'s `CONDITION_MAPS` (itself
validated row-for-row against the legacy MATLAB `aggregate_aff_inj.m`):

```python
CONDITION_MAPS = {
    "aggregated_condition_affective": {1: "Aff Coher", 2: "Aff Opp", 3: "Aff Coher", 4: "Aff Opp"},
    "aggregated_condition_injected":  {1: "Ref",       2: "Ref",     3: "Inj",       4: "Inj"},
}
```

with `track_condition` 1-4 mapped to `TT`/`TF`/`FT`/`FF` by
`core/extract.py`'s `COND_MAP`. Cross-referencing the two:

| code | narrative authenticity (1st letter) | affective coherence (2nd letter) |
|------|--------------------------------------|-----------------------------------|
| TT   | T = Reference                        | T = Coherent                      |
| TF   | T = Reference                        | F = Opposite                      |
| FT   | F = Injected                          | T = Coherent                      |
| FF   | F = Injected                          | F = Opposite                      |

So the letter order is **(narrative authenticity, affective coherence)** —
first letter Reference(T)/Injected(F), second letter Coherent(T)/Opposite(F).

## Four-condition representative excerpt

For any symphony/movement, its four
displayed-condition texts are, within that movement's 18-row block:

- row 0 → TT (Reference, Coherent)
- row 1 → TF (Reference, Opposite)
- one of rows {2,4,6,8,10,12,14,16} → FT (Injected, Coherent)
- one of rows {3,5,7,9,11,13,15,17} → FF (Injected, Opposite)
